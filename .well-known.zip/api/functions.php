<?php

/**
* Queries the database and checks whether the user already exists
* 
* @param $username
* 
* @return
*/
function userExists($username){
	$query = "SELECT username FROM users WHERE username = ?";
	global $con;
	//$stmt = mysqli_prepare($con, $query);
	//echo $con->prepare($query);
	if($stmt = mysqli_prepare($con, $query)){
		$stmt->bind_param("s",$username);
		$stmt->execute();
		$stmt->store_result();
		$stmt->fetch();
		if($stmt->num_rows == 1){
			$stmt->close();
			return true;
		}
		$stmt->close();
	}
 
	return false;
}
 

?>